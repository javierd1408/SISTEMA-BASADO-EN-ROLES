<section class="proximamente">
  <h2>🔧 Proyectos en desarrollo</h2>
  <p>Estamos trabajando en algo emocionante. ¡Muy pronto podrás explorar nuestros proyectos aquí!</p>
</section>